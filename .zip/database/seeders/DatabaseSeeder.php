<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        // $this->call(EmpresaSeeder::class);
        $this->call(ProvinciaSeeder::class);
        $this->call(RolesSeeder::class);
        $this->call(UnidadJudicialSeeder::class);
        $this->call(JuicioSeeder::class);
       
    }
}
